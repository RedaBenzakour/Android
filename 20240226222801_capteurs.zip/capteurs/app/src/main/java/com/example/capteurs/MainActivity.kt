package com.example.capteurs

import androidx.appcompat.app.AppCompatActivity
import android.content.Context
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var temperatureTextView: TextView
    private lateinit var colorTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        temperatureTextView = findViewById(R.id.temperatureTextView)
        colorTextView = findViewById(R.id.colorTextView)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)

        if (temperatureSensor == null) {
            temperatureTextView.text = "Capteur de température non disponible sur cet appareil."
        } else {
            sensorManager.registerListener(this, temperatureSensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_AMBIENT_TEMPERATURE) {
            val temperature = event.values[0]
            temperatureTextView.text = "Température : $temperature°C"
            val color = calculateColor(temperature)
            colorTextView.setTextColor(color)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Ignorer pour le moment
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onResume() {
        super.onResume()
        val temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
        if (temperatureSensor != null) {
            sensorManager.registerListener(this, temperatureSensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    private fun calculateColor(temperature: Float): Int {
        val minTemp = -10.0f
        val maxTemp = 40.0f
        val scaledTemp = (temperature - minTemp) / (maxTemp - minTemp)
        val red = (255 * scaledTemp).toInt()
        val blue = (255 * (1 - scaledTemp)).toInt()
        return Color.rgb(red, 0, blue)
    }
}
